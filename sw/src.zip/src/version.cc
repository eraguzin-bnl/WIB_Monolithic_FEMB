#include "version.h"

char const *const GIT_VERSION = "";