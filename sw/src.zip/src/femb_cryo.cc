#include "femb_cryo.h"

#include <unistd.h>
#include <cstdio>

FEMB_CRYO::FEMB_CRYO(int _index) : index(_index) {

}

FEMB_CRYO::~FEMB_CRYO() {

}
