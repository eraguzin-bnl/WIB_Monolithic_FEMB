#ifndef version_h
#define version_h

extern char const *const GIT_VERSION;

#endif
